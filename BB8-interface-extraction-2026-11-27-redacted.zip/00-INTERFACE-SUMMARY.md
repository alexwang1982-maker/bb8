# BB-8 大脑接入：当前真实接口清单（只读提取，2026-11-27）

运行进程确认：`python bridge.py`（PID 6724）、`python app.py`（PID 28004 / 20444）。
当前实际项目根目录：`G:\openmuse\xiaozhi-server\`；服务端源码：`G:\openmuse\xiaozhi-server\src\xiaozhi-esp32-server-main\main\xiaozhi-server\`。

## 1. Brain

**未实现本地 brain.py**：全盘 `G:\` 递归查找 `brain.py` 与 `brain\__init__.py` = 0 个结果（见 `00-BRAIN-ABSENCE.txt`）。
当前“大脑”由两段外部调用组成，完整源码在 `bridge/bridge.py`：

| 项 | 真实接口 |
|---|---|
| Brain 工具入口 | `ASK_BRAIN_TOOL` / `ASK_BRAIN_NAME = "ask_brain"`，参数 `{"question": string}`（`bridge.py:176-191`） |
| 调度点 | `BridgeHandler._handle_agnes_chat()`：`bridge.py:1685-1705`，最多 `MAX_BRAIN_ROUNDS=4` 轮（`:51`） |
| 线程/会话 | `get_thread(key, persona) -> (thread_id, fresh)`：`bridge.py:132-145`；`POST /api/threads` |
| 发送与取结果 | `run_turn(tid, user_text, persona, timeout) -> (text, err)`：`bridge.py:148-172`；`POST /api/threads/{id}/send` + `GET /api/threads/{id}/events?limit=50` |
| OpenMuse 地址 | `BASE = OPENMUSE_BRIDGE_TARGET`，默认 `http://127.0.0.1:8890`（`:24`） |
| 鉴权 | `Authorization: Bearer <G:\openmuse\data\server_token>`（`:52,85-103`） |
| 输出结构 | 字符串 `brain_result` 回灌为 OpenAI 兼容 `role=tool` 消息：`{"role":"tool","tool_call_id":call["id"],"content":brain_result}`（`:1697-1704`）；无本地 Brain 输出对象 |
| LLM 层 | `agnes_chat()`：`bridge.py:388-471`，返回 `{"content":..., "tool_calls":[...], "finish_reason":...}` |
| 转电脑助手 | `FORWARD_TO_PC_TOOL` / `opencode_forward.forward(text)`：`bridge.py:194-214,1706-1732`；`bridge/opencode_forward.py:117-132` |

## 2. Bridge

- 完整源码：`bridge/bridge.py`（94,469 B）。
- 进程入口：`bridge/start_bridge.ps1`；HTTP 服务 `ThreadingHTTPServer`，端口 `OPENMUSE_BRIDGE_PORT` 默认 8900（`:25-26,1940`）。
- 与设备侧（xiaozhi-server）关系：Bridge 作为 OpenAI 兼容客户端把 `tool_calls` 通过 SSE 发给 xiaozhi-server；`_stream_tool_calls()`：`bridge.py:1832-1838`。
- 与 Brain 关系：见上表；普通聊天直接由 AGNES LLM 回答，只有 `ask_brain` 工具调用才进 OpenMuse。
- 设备工具注册：由设备通过 MCP `tools/list` 上报；服务端 `core/providers/tools/device_mcp/mcp_handler.py:67-129` 注册，`mcp_client.py:61-65` 将点号名 sanitize 为下划线名并保留 `name_mapping`；Bridge 侧必须用下划线名（如 `self_camera_send`、`self_camera_latest`），见 `bridge.py:1233-1235`。
- 设备工具调用链：Bridge SSE tool_calls → xiaozhi `unified_tool_handler.py:148/178` → `unified_tool_manager.execute_tool()` → `mcp_handler.call_mcp_tool()`（`mcp_handler.py:206-321`）→ WebSocket `{"type":"mcp","payload":{"method":"tools/call"...}}` → 设备 MCP server。
- 摄像头入口：`capture_image()` / `vision_look()`（`bridge.py:1099-1173`）；`camera_mgmt_request()` / `camera_latest_request()`（`:1221-1282`）。
- 快通道去重：`_fast_tool_seen`（`:59-61`）；每轮最多一个设备动作由提示词约束 `BPLUS_RULES`（`:215-240`）。

## 3. 摄像头 / `self.camera.latest`

**已实现（Bridge 侧抓图 + VLM）**：`bridge.py:1034-1173`。
- 取图：`urllib.request.urlopen(url, timeout≤2s)`，`url` 来自 `BB8_CAM_URL` 默认 `http://192.168.1.9/capture`、`BB8_CAM_URLS` 多地址、按 `BB8_CAM_MAC=80:45:6b:cf:b2:40` 查 ARP 动态置顶（`:1039-1084,1099-1132`）。
- 成功判据：`len(img) >= 1000` bytes；否则记 `too small`；全失败返回 `None`。
- 编码：`base64.b64encode(img).decode()` → `"data:image/jpeg;base64," + b64`（`:1145,1155-1157`）。源码未校验 HTTP 返回的实际图像头/分辨率。
- 分辨率：抓图路径代码不解析分辨率。设备侧串口识别数据坐标为 `320,240`（`$000,000,320,240,#`），这是识别坐标系，不等于 `/capture` 的 JPEG 分辨率；JPEG 实际分辨率 **无法确认**。
- 失败处理：`capture_image()` 返回 None → `vision_look()` 返回 `VISION_FAIL_MSG = "我现在看不清，等一下再试"`（`:1092,1143-1144`）；异常同样返回该短句（`:1171-1173`）。

**`self.camera.latest` 完整固件实现：无法确认。** 当前磁盘不存在固件源码目录（`bb8_board.cc` / `mcp_server.cc` 全盘搜索 0 结果；原 `D:\Temp\opencode\xiaozhi-src` 已不存在）。当前项目中只存在接口证据与调用侧路由，见 `00-CAMERA-EVIDENCE.txt`。已知接口返回形态：`"age_ms=<ms>\n<串口缓存数据>"`，例如 `age_ms=186281\n$000,000,320,240,#`；`$000,000,320,240,#` 为“未检测到目标”的默认数据（见证据文件）。不要把它当作图像字节。

## 4. 视觉模型

**已经接入，完整实现在 `bridge/vision_look()`（`bridge.py:1136-1173`）**，不需要另装模型/另接新服务。
- 供应商：`https://api.siliconflow.cn/v1/chat/completions`
- 模型：`SF_VISION_MODEL`，默认 `Qwen/Qwen3-VL-8B-Instruct`（`:1087`）
- 输入：`messages[0]` system 中文提示；`messages[1].content` 为 `[{"type":"image_url","image_url":{"url":"data:image/jpeg;base64,<b64>"}},{"type":"text","text":question}]`；`max_tokens=300`
- 超时：`SF_VISION_TIMEOUT` 默认 6s（`:1091`）
- 返回：`j["choices"][0]["message"]["content"]` 文本；空值/异常 → `VISION_FAIL_MSG`
- 触发词：`VISION_TRIGGERS`（`:1093-1096`），`vision_request()`（`:1209-1218`）；“眼睛灯”被排除（走设备工具 `self_eye_set`）。
- 未实现：本地图像持久化、图像 URL 返回、结构化目标检测输出；Bridge 只产出文本回答。

## 5. 设备执行反馈

- 实际调用链见第 2 节；返回解析在 `mcp_handler.py:297-315`：`isError=true` → 抛 `RuntimeError`；否则取 `content[0]["text"]` 字符串返回；其他形态 `str(raw_result)`；超时 30s（默认，可传）→ `TimeoutError`。
- 成功/失败/拦截区分：源码层只有 `isError` 与文本字符串；`bridge.py:235` 规定工具返回以 `blocked:` 开头表示拒绝、未执行，但没有本地结构化解析器。设备固件侧的 `blocked: ...` 文案在本机无源码可确认（固件源码缺失）。
- `self.status`：走同一 MCP 链，工具名 `self_status`（`core/bb8_safe_test.py:44`）。返回是 JSON 文本字符串，字段集合见 `core/bb8_safe_test.py:54-98`：14 个整数字段 `left_limit,right_limit,center_limit,head_press,impact,head_motor,drive_motor,estop,impact_latched,drive_fault,head_fault,motion_inhibit_ms,follow_mode,safety_gen`；其中 11 个为 0/1；`head_motor`/`drive_motor` ∈ [-100,100]；`motion_inhibit_ms`、`safety_gen` 非负。校验逻辑 `:379-423`。
- `self_motor_drive` / `self_motor_stop` / `self_motor_brake_now`：Bridge 只发下划线工具名（规则与快通道 `bridge.py:876-912`），服务端按 `name_mapping` 还原点号名发给设备（真实名 `self.motor.drive` / `self.motor.stop` / `self.motor.brake.now`，见 MCP tools/list 历史日志）；设备侧执行实现源码缺失，无法提供完整固件调用链。

## 6. Task Engine

- 完整源码：`bridge/task_engine.py`（71,673 B）；SQLite DB：`bridge/tasks.db`。
- 实际入口：`task_engine.handle_request(method, path, body) -> (http_code, dict)`（`task_engine.py:1439-1478`），由 `bridge.py:1338-1339,1388-1393` 代理 `/tasks/*`。
- 路由：`POST /tasks/submit`（`idempotency_key,kind,payload,device_id,priority,max_attempts,retry_policy` → 202）、`/tasks/cancel|pause|resume|retry`、`GET /tasks/status?id=`、`/tasks/list?limit=&status=`、`/tasks/events?id=&limit=`、`/tasks/result?id=`、`/tasks/health`。
- 函数：`submit(...) -> {"task":row,"duplicate":bool}`（`:760-779`）、`status(task_id) -> dict|None`（`:782-784`）、`list_tasks`（`:787`）、`events`（`:797`）、`outbox`（`:946`）、`cancel/pause/resume/retry`（`:828-945`）、`recover/init`（`:703,1423`）。
- 任务状态/结果反馈：状态在 `tasks` 表 `_row_dict`（`:203`）返回；结果在 `outbox` 表，`_write_outbox_tx()`（`:1285`）、`GET /tasks/result` 返回 `{"outbox":[...]}`。

## 状态标注

| 功能 | 状态 |
|---|---|
| `bridge.py` / `task_engine.py` / OpenMuse HTTP Brain / AGES LLM tool-calling / SiliconFlow VLM | 已实现，完整源码在 ZIP |
| 服务端 MCP 工具注册、调用、结果解析 | 已实现，完整源码在 ZIP |
| `self.status` 字段契约与校验 | 已实现（服务端侧），完整源码在 ZIP |
| 本地 `brain.py` / `brain/__init__.py` | 未实现（全盘不存在） |
| `self.camera.latest` 固件实现、电机固件执行与 `blocked:` 文案 | 无法确认（固件源码不在本机） |
| 抓图 JPEG 实际分辨率 | 无法确认（代码不解析图像头） |
| Git commit / 工作区状态 | 无法确认（相关目录均非 Git 仓库） |
